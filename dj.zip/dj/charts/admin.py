from django.contrib import admin
from .models import Jugador


# Register your models here.
admin.site.register(Jugador)
